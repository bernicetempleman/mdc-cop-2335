#include <iostream>
#include <stack>
#include <cstddef>

using namespace std;

struct StackFrame
{
 char data;
 StackFrame *link;
};
typedef StackFrame* StackFramePtr;

class Stack
{
public:
 Stack( );
 Stack(const Stack& a_stack);
 ~Stack( );
 void push(char the_symbol);
 char pop( );
 bool empty( ) const;
private:
 StackFramePtr top;
};
void Stack::push(char the_symbol)
{
 StackFramePtr temp_ptr;
 temp_ptr->data = the_symbol;
 temp_ptr->link = top;
 top = temp_ptr;
}

 B) void Stack::push(char the_symbol)
{
 StackFrame temp_ptr;
 temp_ptr = new StackFrame;
 temp_ptr -> data = the_symbol;
 temp_ptr -> link = top;
 top = temp_ptr;
}
 C) void Stack::push(char the_symbol)
{
 StackFramePtr temp_ptr;
 temp_ptr = new StackFrame;
 temp_ptr->data = the_symbol;
 temp_ptr->link = top;
 top = temp_ptr;
}
 D) void Stack::push(char the_symbol)
{
 StackFramePtr temp_ptr;
 temp_ptr = new StackFrame;
 temp_ptr->data = the_symbol;
 temp_ptr->link = top;
}


int main()
{
    cout << "Hello world!" << endl;
    return 0;
}
