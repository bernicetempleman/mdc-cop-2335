#include <iostream>

using namespace std;


struct StackFrame
{
 char data;
 StackFrame *link;
};
//StackFrame* StackFramePtr;

class Stack
{
public:
 Stack( );
 Stack(const Stack& a_stack);
 ~Stack( );
 void push1(char the_symbol);
  void push2(char the_symbol);
   void push3(char the_symbol);
    void push4(char the_symbol);
 bool empty( ) const;
private:
    StackFrame* StackFramePtr;
// StackFramePtr top;
};
/*
 void Stack::push1(char the_symbol)
{
 StackFramePtr temp_ptr;
 temp_ptr->data = the_symbol;
 temp_ptr->link = top;
 t

void Stack::push2(char the_symbol)
{
 StackFrame temp_ptr;
 temp_ptr = new StackFrame;
 temp_ptr -> data = the_symbol;
 temp_ptr -> link = top;
 top = temp_ptr;
};

void Stack::push3(char the_symbol)
{
 StackFramePtr temp_ptr;
 temp_ptr = new StackFrame;
 temp_ptr->data = the_symbol;
 temp_ptr->link = top;
 top = temp_ptr;
};
 */
void Stack::push4(char the_symbol)
{
 StackFramePtr temp_ptr;
 temp_ptr = new StackFrame;
 temp_ptr->data = the_symbol;
 temp_ptr->link = top;
};



int main()
{

    char sym;
    Stack stack;

   // stack.push1('2');
    //stack.push2('2');
   // stack.push3('2');
    stack.push4('2');

    return 0;
}
