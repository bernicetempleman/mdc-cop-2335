#ifndef NUMBERLIST_H
#define NUMBERLIST_H


class NumberList
{
    private:
        struct ListNode
        {
            double value;
            ListNode  *next;
        };

        ListNode *head;

    protected:

    public:
        NumberList( )
        {head = nullptr;}
        ~NumberList();

        void appendNode(double);

        void insertNode(double);
        void deleteNode(double);
        void displayList() const;


};

#endif // NUMBERLIST_H
