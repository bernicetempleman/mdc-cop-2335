#include <iostream>

using namespace std;

struct DateType
{
 int day;
 int month;
 int year;
};

struct PersonType
{
 int age;
 float weight;
 DateType birthday;
};


int main()
{
    PersonType person;

    int * p1;

   // p1 = 2;
      cout << p1<<endl;
    p1++;
    cout << p1<<endl;


//    cout << birthday.year;
 cout << person.birthday.year;
 //cout << person.year;
 //cout << year;

    cout << "Hello world!" << endl;
    return 0;
}
