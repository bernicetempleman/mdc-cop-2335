#include <iostream>

using namespace std;

const int NUM_MONTHS = 12;

struct WeatherData
{
    double totalRainfall;
    double highTemp;
    double lowTemp;
    double avgTemp;
};

void displaySampleData();

void getData(WeatherData [], int);
void calcAvg(WeatherData [], int);

void display(const WeatherData [], int);


int main()
{
    WeatherData month[NUM_MONTHS];

    getData( month, NUM_MONTHS);
    calcAvg( month, NUM_MONTHS);

    display( month, NUM_MONTHS);


    return 0;
}

void getData(WeatherData w[], int num)
{
    displaySampleData();
    for (int i = 0; i < num; i++)
    {
        cout << "Enter data for Month : " << i+1 << endl;
        cout << "Total Rainfall: ";
        cin >> w[i].totalRainfall ;
        cout << "High Temp: "<< endl;
        cin >> w[i].highTemp;
        cout << "Low Temp: ";
        cin >> w[i].lowTemp;
    }
}

void calcAvg(WeatherData w[], int num)
{
    for (int i = 0; i < num; i++)
    {
        w[i].avgTemp = (w[i].highTemp + w[i].lowTemp)/2;
    }

}

void display (const WeatherData w[], int num)
{

    for (int i = 0; i < num; i++)
    {
        cout << "Month "<< i+1<< " Average Temp: "<< w[i].avgTemp <<endl;

    }
}

void displaySampleData()
{
    cout << "Sample Data: "<< endl;
    cout << "Month 1: " << "3.24, 57, 39"<< endl;
    cout << "Month 2: " << "3.181, 63, 43"<< endl;
    cout << "Month 3: " << "2.65, 64, 46"<< endl;
    cout << "Month 4: " << "0.89, 70, 46"<< endl;
    cout << "Month 5: " << "0.35, 73, 52"<< endl;
    cout << "Month 6: " << "0.11, 77, 55"<< endl;
    cout << "Month 7: " << "0.031, 79, 57"<< endl;
    cout << "Month 8: " << "0.079, 79, 57"<< endl;
    cout << "Month 9: " << "0.189, 79, 55"<< endl;
    cout << "Month 10: " << "0.85, 73, 50"<< endl;
    cout << "Month 11: " << "1.831, 64, 45"<< endl;
    cout << "Month 12: " << "2.311, 57, 39"<< endl;

}
