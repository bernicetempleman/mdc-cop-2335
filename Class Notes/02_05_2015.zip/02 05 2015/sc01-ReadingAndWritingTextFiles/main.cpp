#include <iostream>
#include <fstream>
#include <cstdlib>

using namespace std;

int main()
{
    // write to a data (output) file
    ofstream outData;

    // open file for writing
    outData.open("MyData.txt");

    outData << 10 << endl;
    outData << 20 << endl;
    outData << 30 << endl;
    outData << 40 << endl;
    outData << 50 << endl;

    outData.close();

    ifstream inData;
    int myNumber;
    inData.open("MyData.txt");

    // safe programming practice
    if(!inData)
    {
        cout << "Trouble locating the file..\nExiting...";
        exit(1);
    }

    // assume the opened correctly
    //while(!inData.eof())
    while(inData>>myNumber)
    {
        cout << myNumber << endl;
    }

    inData.close();

    return 0;
}
