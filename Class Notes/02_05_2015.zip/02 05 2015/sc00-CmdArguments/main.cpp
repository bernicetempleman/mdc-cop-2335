#include <iostream>
#include <cstdlib>
#include <stdio.h>

using namespace std;

int main(int argc, char *argv[])
{
    // argc tells us how many elements are in argv
    // argv contains the actual data

    cout << "argc: " << argc << endl;

    for (int i =0; i<argc; i++)
    {
        cout << "argv[" << i
             << "]"
             << argv[i] << endl;
    }
    //system("pause");
    char ch = getchar();
    return 0;
}
