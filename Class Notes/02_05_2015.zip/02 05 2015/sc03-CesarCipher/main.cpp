#include <iostream>
#include <fstream>
#include <cstdlib>

using namespace std;

const int CIPHER = 5;

int main()
{
    ifstream inFile;
    ofstream outFile;

    outFile.open("Cipher.txt");

    inFile.open("SampleText.txt");
    //if (!inFile)
    if (inFile.fail())
    {
        cout << "Trouble locating the input file. Exiting..." << endl;
        exit(1);
    }

    // read from the input file
    char ch;
    while (inFile >> ch)
    {
        ch = ch + CIPHER;
        outFile << ch;
    }

    inFile.close();
    outFile.close();

    return 0;
}
