#include <iostream>
#include <fstream>

using namespace std;

int main()
{
    fstream myFile.open("MyData.txt" | ios::out | ios::in);

    cout << "Hello world!" << endl;
    return 0;
}
