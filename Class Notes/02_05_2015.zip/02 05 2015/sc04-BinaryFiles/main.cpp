#include <iostream>
#include <fstream>
#include <cstdlib>

using namespace std;

struct ClientInfo
{
    int acctNumber;
    string lastName;
    string firstName;
    double balance;
};

int main()
{
    ClientInfo myClient;

    ofstream outCredit("credit.dat", ios::out | ios::binary);
    if(!outCredit)
    {
        cerr << "Trouble locating the file!" << endl;
        exit(1);
    }

    for (int i=0; i<100; i++)
    {
        outCredit.write(
            reinterpret_cast<const char *>(&myClient),
                         sizeof(myClient));
    }
    outCredit.close();

    // open the file for reading
    fstream myFile ("credit.dat", ios::in|ios::out|ios::binary);
    if (!myFile)
    {
        cerr << "Trouble locating the file!" << endl;
        exit(1);
    }

    cout << "Please account number (1 -100, 0 to end input):";
    ClientInfo aClient;
    cin >> aClient.acctNumber;
    cin.ignore();
    cin.sync();

    // seek into the file to that position
    // safe programming practice is missing - check input 0 -100
    while (aClient.acctNumber > 0 &&
           aClient.acctNumber < 101)
    {
        cout << "Last Name:";
        getline(cin, aClient.lastName);

        cout << "First Name:";
        getline(cin, aClient.firstName);

        cout << "Balance: ";
        cin >> aClient.balance;


        // put the captured data into specified position in the file
        myFile.seekp((aClient.acctNumber-1)* sizeof(ClientInfo));
        myFile.write(reinterpret_cast<const char *>(&aClient),
                 sizeof(ClientInfo));

        cout << "Please account number (1 -100, 0 to end input):";
        cin >> aClient.acctNumber;

        cin.ignore();
        cin.sync();
    }

    myFile.close();
    return 0;
}
