#include <iostream>
#include <string>
#include <memory>

using namespace std;

class Car
{
    private:
        string make;
        string model;
        int year;
        double mpg;
        //double pctDepreciated;

    public:
        // getters
        string getMake() const;
        string getModel() const;
        int getYear() const;
        double getMPG() const;
        //double getPctDepreciated() const;

        // setters
        void setMake(string m);
        void setModel(string m);
        void setYear(int y);
        void setMPG(double mpg);
        void setPctDepreciated(double);

        // utility
        double calcDepreciation(int currYear);
};

string Car::getMake() const
{
    return make;
}

string Car::getModel() const
{
    return model;
}

int Car::getYear() const
{
    return year;
}

double Car::getMPG() const
{
    return mpg;
}

void Car::setMake(string m)
{
    make = m;
}

void Car::setModel(string m)
{
    model = m;
}

void Car::setYear(int y)
{
    year = y;
}

void Car::setMPG(double mpg)
{
    this->mpg = mpg;

}

double Car::calcDepreciation(int currYear)
{
    if (currYear == year)
       return 0;
    else if (currYear > year)
       return 0.20;
}

int main()
{
    // Car myCar ;

    Car *ptrMyCar = new Car;

    // populate the class members with info
    ptrMyCar->setMake("Jaguar");
    ptrMyCar->setModel("F-Type");
    ptrMyCar->setYear(2015);
    ptrMyCar->setMPG(24.5);

    // get data from the class
    cout << "Make: " << ptrMyCar->getMake() << endl;
    cout << "Model: " << ptrMyCar->getModel() << endl;
    cout << "Year: " << ptrMyCar->getYear() << endl;
    cout << "MPG: " << ptrMyCar->getMPG() << endl;

    cout << "My car depreciated "
         << ptrMyCar->calcDepreciation (2050) << endl;
/*
    cout << "My car depreciated "
         << myCar.getPctDepreciated() << endl;
*/

    // clean / deallocate allocated memory
    delete ptrMyCar;
    ptrMyCar = NULL;
    return 0;
}
