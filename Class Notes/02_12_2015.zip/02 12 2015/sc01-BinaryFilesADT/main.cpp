#include <iostream>
#include <fstream>
#include <cstdlib>

using namespace std;

const int NAME_SIZE = 25;
const int MAJOR_SIZE = 35;

struct StudentInfo
{
    int ID;
    char name[NAME_SIZE];
    char major[MAJOR_SIZE];
    double gpa;
};

int main()
{
    StudentInfo myStudents[] = {
        {1001, "Dwyane Wade", "Computer Science", 3.8},
        {1002, "LeBron James", "Political Science", 1.9},
        {1003, "Derek Rose", "Biology", 3.1}
    };

    fstream myFile;
    myFile.open("myStudents.dat", ios::out | ios::binary);
    myFile.write(reinterpret_cast<const char *> (&myStudents),
                           sizeof(myStudents));
    myFile.close();
    myFile.clear();

    myFile.open("myStudents.dat", ios::in | ios::binary);
    if (!myFile)
    {
        cout << "Trouble locating the file. Exiting..." << endl;
        exit(1);  // EXIT_FAILURE
    }

    // read record by record
    // use priming read
    StudentInfo aCOP2335Student;
    myFile.read(reinterpret_cast<char *>(&aCOP2335Student),
                  sizeof(aCOP2335Student));

    while(!myFile.eof())
    {
        // converting from binary to human readable info
        cout << "ID: " << aCOP2335Student.ID << endl;
        cout << "Name: " << aCOP2335Student.name << endl;
        cout << "Major: " << aCOP2335Student.major << endl;
        cout << "GPA: " << aCOP2335Student.gpa << endl;

        myFile.read(reinterpret_cast<char *>(&aCOP2335Student),
                  sizeof(aCOP2335Student));
    }

    // close the file
    myFile.close();
    return 0;
}
