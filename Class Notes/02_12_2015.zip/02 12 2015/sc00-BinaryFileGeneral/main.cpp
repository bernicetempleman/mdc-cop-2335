#include <iostream>
#include <cstdlib>
#include <fstream>

using namespace std;

int main()
{
    fstream myFile;
    int number = 10;
    double average = 14.88;

    myFile.open("myData.dat", ios::out | ios::binary);
    myFile.write(reinterpret_cast<char*>(&number), sizeof(int));
    myFile.write(reinterpret_cast<char*>(&average), sizeof(double));
    myFile.close();

    // safe programming
    myFile.clear();

    // open the file and read the data back
    myFile.open("myData.dat", ios::in | ios::binary);
    if (!myFile)
    {
        cout << "Trouble locating the file. Exiting..." << endl;
        exit(0);
    }


    int aNumber;
    double anAverage;
    myFile.read(reinterpret_cast<char *>(&aNumber), sizeof(int));
    myFile.read(reinterpret_cast<char *>(&anAverage), sizeof(double));

    cout << "Number (read from file): "  << aNumber << endl;
    cout << "Average (read from file): "  << anAverage << endl;
    myFile.close();
    return 0;
}
