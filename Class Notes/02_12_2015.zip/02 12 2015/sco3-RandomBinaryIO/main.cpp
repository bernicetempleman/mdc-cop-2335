#include <iostream>
#include <fstream>
#include <cstring>

using namespace std;

const int NAME_SIZE = 25;
const int MAJOR_SIZE = 35;

struct StudentInfo
{
    int ID;
    char name[NAME_SIZE];
    char major[MAJOR_SIZE];
    double gpa;
};

// function prototypes
void findAndDisplayTheRecord(fstream &, int);

int main()
{
    fstream myFile;
    int recNum;

    StudentInfo myStudents[] = {
        {1001, "Dwyane Wade", "Computer Science", 3.8},
        {1002, "LeBron James", "Political Science", 1.9},
        {1003, "Derek Rose", "Biology", 3.1},
        {1004, "Lolo Jones", "Communications", 2.8},
        {1005, "Shakira", "Business", 4.0}
    };

    // open file for both, input and output
    myFile.open("myStudents.dat", ios::in|ios::out|ios::binary);
    myFile.write(reinterpret_cast<const char *>(&myStudents),
                    sizeof(myStudents));

    // ask the user to provide record # that they want to modify
    cout << "Record number: ";
    cin >> recNum;
    recNum--;

    findAndDisplayTheRecord(myFile, recNum);

    //seekp(sizeof(StudentInfo)*recNum, ios::beg );
    StudentInfo aStudent;

    myFile.read(reinterpret_cast<char *>(&aStudent),
                  sizeof(aStudent));

    strncpy(aStudent.name,"Barak Obama", NAME_SIZE);

    myFile.seekp(0L, ios::cur);
    myFile.write(reinterpret_cast<const char *>(&aStudent),
                    sizeof(aStudent));

    cout << "Record number: ";
    cin >> recNum;
    recNum--;
    findAndDisplayTheRecord(myFile, recNum);
    myFile.close();
    return 0;
}

void findAndDisplayTheRecord(fstream &aFile,
                             int recordNo)
{
    StudentInfo aStudent;
    aFile.seekg((sizeof(StudentInfo)*recordNo), ios::beg);

    // read the data
    aFile.read(reinterpret_cast<char *>(&aStudent),
                  sizeof(aStudent));

    // display the data
    cout << "ID: " << aStudent.ID << endl;
    cout << "Name: " << aStudent.name << endl;
    cout << "Major: " << aStudent.major << endl;
    cout << "GPA: " << aStudent.gpa << endl;

    //tellp
}
