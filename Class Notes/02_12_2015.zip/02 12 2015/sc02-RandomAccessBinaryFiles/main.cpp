#include <cstdlib>
#include <iostream>
#include <fstream>

using namespace std;

const int NAME_SIZE = 25;
const int MAJOR_SIZE = 35;

struct StudentInfo
{
    int ID;
    char name[NAME_SIZE];
    char major[MAJOR_SIZE];
    double gpa;
};

int main()
{
    // inFile.seekp(10L,ios::beg);
    // go to the 11th byte, from the beginning of the file

    // inFile.seekp(5L,ios::cur);
    // from the current position, advance 5 bytes

    // inFile.seekp(-16L,ios::end);
    // from the end of file move 16 bytes back

    fstream outFile;
    StudentInfo myStudents[] = {
        {1001, "Dwyane Wade", "Computer Science", 3.8},
        {1002, "LeBron James", "Political Science", 1.9},
        {1003, "Derek Rose", "Biology", 3.1},
        {1004, "Lolo Jones", "Communications", 2.8},
        {1005, "Shakira", "Business", 4.0}
    };

    outFile.open("myStudents.dat", ios::out | ios::binary);
    outFile.write(reinterpret_cast<char *>(&myStudents),
                    sizeof(myStudents));

    outFile.close();

    fstream inFile;

    inFile.open("myStudents.dat", ios::in | ios::binary);
    if (!inFile)
    {
        cout << "Trouble locating the file. Exiting..." << endl;
        exit(1);  // EXIT_FAILURE
    }

    // read record by record
    // use priming read
    StudentInfo aCOP2335Student;
    inFile.read(reinterpret_cast<char *>(&aCOP2335Student),
                  sizeof(aCOP2335Student));

    while(!inFile.eof())
    {
        // converting from binary to human readable info
        cout << "ID: " << aCOP2335Student.ID << endl;
        cout << "Name: " << aCOP2335Student.name << endl;
        cout << "Major: " << aCOP2335Student.major << endl;
        cout << "GPA: " << aCOP2335Student.gpa << endl;

        inFile.read(reinterpret_cast<char *>(&aCOP2335Student),
                  sizeof(aCOP2335Student));
    }

    // close the file
    inFile.close();

    // read records randomly
    int recNum;    // to keep record num (offset)
    cout << "Reading random records from the file"<< endl;
    cout << "Record number: ";
    cin >> recNum;
    recNum--;

    inFile.clear();
    inFile.open("myStudents.dat", ios::in | ios::binary);
    if (!inFile)
    {
        cout << "Trouble locating the file. Exiting..." << endl;
        exit(1);  // EXIT_FAILURE
    }

    // seek into the file and display
    cout << "Here is your record: ";

    // move the file pointer to desired location
    inFile.seekg((sizeof(StudentInfo)*recNum), ios::beg);

    // read the data
    inFile.read(reinterpret_cast<char *>(&aCOP2335Student),
                  sizeof(aCOP2335Student));

    // display the data
    cout << "ID: " << aCOP2335Student.ID << endl;
    cout << "Name: " << aCOP2335Student.name << endl;
    cout << "Major: " << aCOP2335Student.major << endl;
    cout << "GPA: " << aCOP2335Student.gpa << endl;

    // write a code segment to change a record

    inFile.close();
    return 0;
}
