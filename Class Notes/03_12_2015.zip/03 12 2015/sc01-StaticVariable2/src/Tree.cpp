#include "Tree.h"

Tree::Tree()
{
    objectCount = 0;
    objectCount++;

    forest++;
}

Tree::~Tree()
{
    //dtor
}

int Tree::getForestCount()
{
    return forest;
}

int Tree::getObjectCount() const
{
    return objectCount;
}
