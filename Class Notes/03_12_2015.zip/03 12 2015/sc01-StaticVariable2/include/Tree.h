#ifndef TREE_H
#define TREE_H

using namespace std;

class Tree
{
    public:
        Tree();
        ~Tree();
        int getObjectCount() const;
        static int getForestCount();
    protected:
    private:
        int objectCount;
        static int forest;
};

#endif // TREE_H
