#include <iostream>
#include "Tree.h"

using namespace std;

int main()
{
    Tree palm;
    Tree oak;
    Tree elm;
    Tree pine;


    cout << "I have " << pine.getObjectCount() << " pine trees "  << endl;
    cout << "I have " << oak.getForestCount() << " trees  in my forest"  << endl;

    return 0;
}

 // initialize the static
 int Tree::forest;

