#ifndef COUNTER_H
#define COUNTER_H

using namespace std;

class Counter
{
     int counter;
     int limit;

     public:
                static int nCounters;

                Counter(int x, int y);

                void increment();
                void decrement();

                int getValue();

                static int getNCounters();
};

#endif // COUNTER_H
