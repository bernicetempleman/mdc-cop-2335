#include <iostream>
#include "Counter.h"

using namespace std;

int main()
{
    Counter myCounter(5, 2);
    cout << "HOw many counters: " << myCounter.getNCounters() << endl;
    return 0;
}

int Counter::nCounters = 0;
