#include "Counter.h"

 Counter::Counter(int x, int y)
 {
                nCounters = 0;
                counter = x;
                limit = y;

                nCounters++;
        }

        void Counter::increment()
        {
                if(counter < limit)
                {
                        counter++;
                }
        }

        void Counter::decrement()
        {
                if(counter > 0)
                {
                        counter--;
                }
        }

        int Counter::getValue()
        {
                return counter;
        }

        int Counter::getNCounters()
        {
                return nCounters;
        }

