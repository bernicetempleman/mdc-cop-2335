#include <iostream>

using namespace std;

void showLocal();
void showLocalStatic();

int main()
{

    for (int i = 0; i< 10; i++)
    {
        //showLocal();
        showLocalStatic();
    }

    return 0;
}

void showLocalStatic()
{
    static int localNumber = 10;
    cout << "this is local static variable number: " << localNumber << endl;
    localNumber++;
}

void showLocal()
{

    int number = 3;
    cout << "this is local variable number: " << number << endl;
    number++;
}
