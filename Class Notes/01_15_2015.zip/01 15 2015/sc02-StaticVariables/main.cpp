#include <iostream>

using namespace std;

int a ;

// Function prototypes
void displayNumber();
void justinsQuestion();

int main()
{
    displayNumber();
    displayNumber();
    displayNumber();
    justinsQuestion();
    return 0;
}

void displayNumber()
{
   int x = 0;
   x = x + 1;
   cout << "This is x: " << x << endl;
}

void justinsQuestion()
{
   //cout << "Trying to access static x: " << x << endl;
   cout << "Trying to access global a: " << a << endl;
}
