#include <iostream>

using namespace std;

void fahren2Cels(const double &);

int main()
{
    double tempF;

    cout << "Enter degrees F: ";
    cin >> tempF;
    fahren2Cels(tempF);
    cout << "tempF from the main funciton: " << tempF << endl;
    return 0;
}

void fahren2Cels(const double &tempF)
{
   // tempF = tempF + 100;
    double cels = 5.0 / 9 * (tempF - 32);
    cout << tempF << " Fahrenheit degrees is "
         << cels << " degrees Celsius"
         << endl;
}
