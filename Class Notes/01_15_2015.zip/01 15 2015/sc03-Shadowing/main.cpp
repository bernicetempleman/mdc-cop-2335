#include <iostream>

using namespace std;

double tempFF = 100;

void fahren2Cels(double );

int main()
{
    cout << "Enter degrees F: ";
    cin >> tempFF;
    fahren2Cels(tempFF);
    return 0;
}

void fahren2Cels(double fahren)
{
    double tempFF;

    cout << "in fahren2Cels: TempF = " << tempFF << endl;

    double cels = 5.0 / 9 * (fahren - 32);
    cout << fahren << " Fahrenheit degrees is "
         << cels << " degrees Celsius"
         << endl;
}


