#include <iostream>
#include "Gradebook.h"

using namespace std;

int main()
{
    // variables
    string      courseName;
    string      abbr;
    int         section;


    cout << "Enter your course name: ";
    getline(cin, courseName);

    cout << "Enter course abbreviation: ";
    getline(cin, abbr);

    cout << "Section number: ";
    cin >> section;

    //Gradebook   myGB;

    // set the values of attributes
    /*
    myGB.setCourseName(courseName);
    myGB.setCourseAbbr(abbr);
    myGB.setCourseRef(section);
    */

/*
    // dynamic allocation
    Gradebook *ptrMyGB = new Gradebook(courseName,
                                     abbr,
                                     section);

    ptrMyGB->displayMessage();

    delete ptrMyGB;
*/

    // static allocation
    Gradebook myGB;
    myGB.displayMessage();

    return 0;
}
