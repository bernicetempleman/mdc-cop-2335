#include "Gradebook.h"

Gradebook::Gradebook()
{
    //ctor
    cout << "in Gradebook default constructor" << endl;
}

Gradebook::Gradebook(string cName,
                     string cAbbr,
                     int    cRef)
{
   setCourseName(cName);
   setCourseAbbr(cAbbr);
   setCourseRef(cRef);
}

Gradebook::~Gradebook()
{
    //dtor
    cout << "in Gradebook deconstructor" << endl;
}

void Gradebook::displayMessage()
{
    cout << "Welcome to "
         << getCourseName()
         << ", Section number: "
         << courseRef
         << endl;
}
