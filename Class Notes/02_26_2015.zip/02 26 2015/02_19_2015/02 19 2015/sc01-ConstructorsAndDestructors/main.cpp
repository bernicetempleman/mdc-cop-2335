#include <iostream>

using namespace std;

class GradeBook
{
    string courseName;
    string courseAbbr;
    int    courseRef;
public:
    // Constructor  - special method
    GradeBook();   // default constructor
    GradeBook(string cName, string cAbbr, int cRef);

    // destructor - special methos
    ~GradeBook();

    // getters setters
    string getCourseName() const;
    string getCourseAbbr() const;
    int getCourseRef() const;

    void setCourseName(string );
    void setCourseAbbr(string );
    void setCourseRef(int );

    // utility methods
    void displayMessage();
};

string GradeBook::getCourseName() const
{
    return courseName;
}

string GradeBook::getCourseAbbr() const
{
    return courseAbbr;
}

int GradeBook::getCourseRef() const
{
    return courseRef;
}

void GradeBook::setCourseName(string courseName)
{
    this->courseName = courseName;
}

void GradeBook::setCourseAbbr(string courseAbbr)
{
    this->courseAbbr = courseAbbr;
}

void GradeBook::setCourseRef(int r)
{
    this->courseRef = r;
}

GradeBook::GradeBook()
{
    cout << "In default constructor" << endl;
}

GradeBook::GradeBook(string cName, string cAbbr, int cRef)
{
    setCourseName(cName);
    setCourseAbbr(cAbbr);
    setCourseRef(cRef);
}

GradeBook::~GradeBook()
{
    cout << "In default destructor" << endl;
}

void GradeBook::displayMessage()
{
    cout << "Welcome to: " << getCourseName();
    cout << "|Section number: " << courseRef << endl;
}

int main()
{
    // GradeBook *ptrMyGB = new GradeBook();  // default constructor

    GradeBook *ptrMyGB = new GradeBook("Advance C++", "COP2335", 82435);
    ptrMyGB->displayMessage();

    delete ptrMyGB;
    ptrMyGB = NULL;
    return 0;
}
