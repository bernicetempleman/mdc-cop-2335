#include <iostream>

#include <string>




using namespace std;




class Animal

{

public:

    Animal(){};
    virtual ~Animal(){};

    virtual string getSpeak()=0;  // pure virtual function

};




class Cat:public Animal

{
    public:

    Cat(){};

    string getSpeak(){return "Meow";};



};




class Dog:public Animal

{
    public:

    Dog(){};

    string getSpeak(){return "Woof";};



};




class Sheep:public Animal

{
public:
    Sheep(){};

    string getSpeak(){return "Baaah";};



};




class Cow:public Animal

{
public:
    Cow(){};

    string getSpeak(){return "MooMoo";};



};




class Duck:public Animal

{
public:
    Duck(){};

    string getSpeak(){return "Quack";};



};







void doSpeak(Animal *);




int main()

{



    Animal *dog = new Dog();

    Animal *cat = new Cat();

    Animal *duck = new Duck();

    Animal *cow = new Cow();

    Animal *sheep = new Sheep();



    doSpeak(dog);

    doSpeak(cat);

    doSpeak(duck);

    doSpeak(cow);

    doSpeak(sheep);



    delete dog;

    delete cat;

    delete duck;

    delete cow;

    delete sheep;



    return 0;

}




void doSpeak(Animal *animal)

{

    cout << animal->getSpeak() << endl;

}
