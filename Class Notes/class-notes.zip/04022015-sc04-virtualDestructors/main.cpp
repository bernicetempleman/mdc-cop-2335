#include <iostream>

#include <string>




using namespace std;







// base class

class PetType

{

public:

    PetType(string n="");

    virtual ~PetType();  // forcing the child's class destructor to fire

    virtual void print();

private:

    string name;

};




class DogType : public PetType

{

public:

    DogType(string n="",string b="");

    ~DogType();

    void print();

private:

    string breed;

};




PetType::PetType(string n)

{

    cout << "in PetType constructor" << endl;

    name = n;

}




PetType::~PetType()

{

    cout << "in PetType destructor" << endl;

}




void PetType::print()

{

    cout << "in PetType::print ";

    cout << "Name: " << name << endl;

}




DogType::DogType(string name, string breed):PetType(name)

{

    cout << "in DogType constructor" << endl;

    this->breed = breed;

}




DogType::~DogType()

{

    cout << "in DogType destructor" << endl;

}




void DogType::print()

{

    PetType::print();

    cout << "in DogType::print ";

    cout << "Breed: " << breed << endl;

}




// function prototypes

void callPrint(PetType );




int main()

{

    PetType *ptrPet;

    ptrPet = new DogType("Lucky", "Irish Setter");




    delete ptrPet;  // clean the memory




    return 0;

}




void callPrint(PetType p)

{

    p.print();

}
