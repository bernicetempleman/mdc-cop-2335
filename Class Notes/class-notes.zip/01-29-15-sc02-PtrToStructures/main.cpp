#include <iostream>




using namespace std;




struct CarInfo

{

    string make;

    string model;

    int year;

    double mpg;

};




int main()

{

    CarInfo myCar = {"Ferrari", "458", 2015, 8.2};

    CarInfo *ptrMyDreamCar;



    ptrMyDreamCar = &myCar;


/* won't work

    cout << "Make : " << ptrMyDreamCar.make  << endl;

    cout << "Model : " << ptrMyDreamCar.model  << endl;

    cout << "Year : " << ptrMyDreamCar.year  << endl;

    cout << "MPG : " << ptrMyDreamCar.mpg  << endl;
*/

     cout << "Make : " << (*ptrMyDreamCar).make  << endl;

    cout << "Model : " << (*ptrMyDreamCar).model  << endl;

    cout << "Year : " << (*ptrMyDreamCar).year  << endl;

    cout << "MPG : " << (*ptrMyDreamCar).mpg  << endl;


    cout << "Make : " << ptrMyDreamCar->make  << endl;

    cout << "Model : " << ptrMyDreamCar->model  << endl;

    cout << "Year : " << ptrMyDreamCar->year  << endl;

    cout << "MPG : " << ptrMyDreamCar->mpg  << endl;



    return 0;

}
