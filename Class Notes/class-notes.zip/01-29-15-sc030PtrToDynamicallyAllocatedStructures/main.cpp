#include <iostream>

#include <cstdlib>




using namespace std;




struct CarInfo

{

    string make;

    string model;

    int year;

    double mpg;

};




// prototypes

void displayCars(const CarInfo *, int );
void getData(CarInfo *, int );

int main()

{

    int     numCars;

    CarInfo *ptrCar,     // pointer to the current struct

            *ptrHead;    // pointer to the beginning (head) of the array




    cout << "How many cars do you own: ";

    cin >> numCars;




    cin.ignore();

    cin.sync();




    ptrCar = new CarInfo[numCars];

    ptrHead = ptrCar;




    // safe programming practice

    if (!ptrCar)

    {

        cout << "Unable to successfully allocate required memory...";

        cout << "Exiting...";

        system ("PAUSE");   // Windows only

        exit(0);

    }




    // populate the array with dATA

    getData(ptrCar, numCars);



    // reassign ptrHead to ptrCar

    ptrCar = ptrHead;




    // display cars

    displayCars(ptrCar, numCars);







    // deallocate memory

    delete []ptrHead;

    ptrHead = NULL;

    ptrCar = NULL;




    return 0;

}

void getData(CarInfo *ptrVehicle, int numCars)
{
  for (int i=0; i< numCars; i++)

    {

        cout << "Make: ";

        getline(cin, ptrVehicle->make);




        cout << "Model: ";

        getline(cin, ptrVehicle->model);




        cout << "Year: ";

        cin >> ptrVehicle->year;




        cout << "MPG: ";

        cin >> ptrVehicle->mpg;




        cin.ignore();

        cin.sync();

        ptrVehicle++;

    }


}



void displayCars(const CarInfo *ptrVehicle, int numVehicles)

{

    for (int i=0; i<numVehicles; i++)

    {

        cout << "Make: " << ptrVehicle->make << endl;

        cout << "Model: " << ptrVehicle->model << endl;

        cout << "Year: " << ptrVehicle->year << endl;

        cout << "MPG: " << ptrVehicle->mpg << endl;

        ptrVehicle++;

    }

}


