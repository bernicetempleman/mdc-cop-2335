#include <iostream>
#include <memory>

using namespace std;

class Car

{

    private:

        string make;

        string model;

        int year;

        double mpg;


//comment this out : don't store calculations
        double pctDepreciated;




    public:

        // getters

        string getMake() const;

        string getModel() const;

        int getYear() const;

        double getMPG() const;

        double getPctDepreciated() const;




        // setters

        void setMake(string m);

        void setModel(string m);

        void setYear(int y);

        void setMPG(double mpg);

        void setPctDepreciated(double);




        // utility

        double calcDepreciation(int currYear);

};




string Car::getMake() const

{

    return make;

}




string Car::getModel() const

{

    return model;

}




int Car::getYear() const

{

    return year;

}




double Car::getMPG() const

{

    return mpg;

}




double Car::getPctDepreciated() const

{

    return pctDepreciated;

}




void Car::setPctDepreciated(double pctDep)

{

     pctDepreciated = pctDep;

}




void Car::setMake(string m)

{

    make = m;

}




void Car::setModel(string m)

{

    model = m;

}




void Car::setYear(int y)

{

    year = y;

}




void Car::setMPG(double mpg)

{

    this->mpg = mpg;




}




double Car::calcDepreciation(int currYear)

{

    if (currYear == year)

       return 0;

    else if (currYear > year)

       return 0.20;

}




int main()

{

Car * carPtr;
carPtr = new Car;

carPtr->setMake(" ");
carPtr->setModel(" ");
carPtr->setYear(2015);
carPtr->setMPG(24.5);

cout << "Make: " << carPtr->getMake() << endl;




    Car myCar;

    //dynamically allocate myCar

    // populate the class members with info

    myCar.setMake("Jaguar");

    myCar.setModel("F-Type");

    myCar.setYear(2015);

    myCar.setMPG(24.5);

    myCar.setPctDepreciated(0.05);




    // get data from the class

    cout << "Make: " << myCar.getMake() << endl;

    cout << "Model: " << myCar.getModel() << endl;

    cout << "Year: " << myCar.getYear() << endl;

    cout << "MPG: " << myCar.getMPG() << endl;




    cout << "My car depreciated "

         << myCar.calcDepreciation (2050) << endl;

/*

    cout << "My car depreciated "

         << myCar.getPctDepreciated() << endl;

*/


delete carPtr;
carPtr = NULL;

    return 0;

}
