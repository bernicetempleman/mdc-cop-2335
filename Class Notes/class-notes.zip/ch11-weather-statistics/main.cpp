// Chapter 11, Programming Chaallenge 4
// Weather Statistics
//
/* Description:
1.) define an array of 12 weather data structs
2.) For each element in the array
        Get the weather data
3.) Display the total rainfall for the year
4.) Display the average monthly rainfall
5.) Display the average temps
6.) Display the highest temp month
7.) Display the lowest temp month
*/

#include <iostream>

using namespace std;

//Declaration of the WeatherData structure
struct WeatherData
{
    double rain;            // Total rainfall
    double high;            // High Temperature
    double low;             // low temperature
    double averageTemp;     // Average temperature
};

//Function Prototypes
void getMonthData(WeatherData &);
double totalRain (WeatherData[], int);
double averageMonthlyRainfall(WeatherData[], int);
double averageAverageTemp(WeatherData[], int);
double highestTemp(WeatherData[],int, int &);
double lowestTemp(WeatherData[],int, int &);

int main()
{

    // Constant for the number of months
    const int NUM_MONTHS = 12;

    //Create an array of WeatherData Structures
    WeatherData year[NUM_MONTHS];

    int highestMonth;       // The month with the highest temp
    int lowestMonth;        // The month with the lowest temp

    //Get the weather Data for each month
    cout << "Enter the following information:\n";
    for (int index = 0; index < NUM_MONTHS; index++)
    {
        // Get the rainfall
        cout << "Month " << (index + 1) << endl;
        getMonthData(year[index]);

    }

    // Display the total rainfall
    cout << "\nTotal Rainfall: "
        << totalRain(year, NUM_MONTHS) << endl;

    //Display the average monthly rain
    cout << "Average Monthly rain: "
        << averageMonthlyRainfall(year,NUM_MONTHS) << endl;

    // Display the average temps
    cout << "Average temp: "
        << averageAverageTemp(year, NUM_MONTHS) << endl;

    // Display the highest temp month
    double highest = highestTemp(year,NUM_MONTHS, highestMonth);
    cout << "Highest Temp Month: "
        << highest
        << " (Month "
        << highestMonth << ")\n" << endl;

    // Display the lowest temp month
    double lowest = lowestTemp(year,NUM_MONTHS, lowestMonth);
    cout << "Lowest Temp Month: "
        << lowest
        << " (Month "
        << lowestMonth << ")\n" << endl;

    return 0;
}

//The getMonthData function accepts a WeatherData
// var by reference. It prompsr the user for
//weather data and stores the input in the argument
void getMonthData(WeatherData &data)
{
    //Get the total rainfall for the month
    cout << "\tTotal Rainfall: ";
    cin >> data.rain;

    //get the high temp
    cout <<"\tHigh Temperature: ";
    cin >> data.high;

    // Validate the high temp
    while (data.high < -100 || data.high > 140)
    {
        cout << "ERROR: Temperature must be in the range"
        << "of -100 through 140.\n";
        cout << "\tHigh Temperature: ";
        cin >> data.high;
    }

    //get the low temp
    cout <<"\tLow Temperature: ";
    cin >> data.low;

    // Validate the low temp
    while (data.low < -100 || data.low > 140)
    {
        cout << "ERROR: Temperature must be in the range"
        << "of -100 through 140.\n";
        cout << "\tLow Temperature: ";
        cin >> data.low;
    }

    //calculate the average temperature
    data.averageTemp = (data.high + data.low)/2.0;
}

// The totalRain function accepts an array of WeatherData
// structures and returns the total of all the elements
// rain members
double totalRain (WeatherData data[], int size)
{
    double totalRain = 0;       //accumulator

    // Get the total of the rain members
    for (int index =0; index < size; index++)
        totalRain +=data[index].rain;

    // Return the total
    return totalRain;
}

//accepts an array of WeatherData structs and returnd the
// average monthly rainfall
double averageMonthlyRainfall(WeatherData data[], int size)
{
    //The average is the total amt of rain divide by the num months
    return totalRain(data, size)/size;
}

// accepts array of weatherData structs and returns the ave of
// all the monthly temps
double averageAverageTemp(WeatherData data[], int size)
{
    double aveTotal = 0;        // Accumulator for the average temps
    double aveAve;              // Average of the averages

    // Get the total of the average temps
    for (int index = 1; index < size; index++)
        aveTotal += data[index].averageTemp;

    //Calculate the average of averages
    aveAve = aveTotal /size;

    //return the average of averages
    return aveAve;
}

//The highestTemp function accepts:
// 1) a weather Data array
// 2) an int indicating the size of the array
// 3) an int by reference to hold the month with the highest temp
// The function returns the highest temperature
// and sets the month parameter to the number of the month with highest temp
double highestTemp(WeatherData data[],int size, int &month)
{
    //Set the highest to the first month
    double highest = data[0].high;

    // Step through the array looking for the highest
    for( int index = 1; index < size; index ++)
    {
        if (data[index].high > highest)
        {
            // save this value. it is the highest so far
            highest = data[index].high;

            // save this month's number, (1 =Jan)
            month = index + 1;
        }
    }

    //return the highest temp
    return highest;

}

//The lowestTemp function accepts:
// 1) a weather Data array
// 2) an int indicating the size of the array
// 3) an int by reference to hold the month with the lowest temp
// The function returns the lowest temperature
// and sets the month parameter to the number of the month with lowest temp
double lowestTemp(WeatherData data[],int size, int &month)
{
        //Set the lowest to the first month
    double lowest = data[0].high;

    // Step through the array looking for the highest
    for( int index = 1; index < size; index ++)
    {
        if (data[index].low < lowest)
        {
            // save this value. it is the lowest so far
            lowest = data[index].low;

            // save this month's number, (1 =Jan)
            month = index + 1;
        }
    }

    //return the highest temp
    return lowest;
}
