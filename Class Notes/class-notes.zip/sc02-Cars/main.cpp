#include <iostream>




using namespace std;




class Cars

{

 public:

     Cars();

     ~Cars();



     // getters & setters

     void setMake(string make);

     void setModel(string model);

     void setYear(int year);

     void setMPG(double mpg);



 private:

    string make;

    string model;

    int year;

    double mpg;

};




void Cars::setMake(string make)

{

    this->make = make;

}
















int main()

{

    cout << "Hello world!" << endl;

    return 0;

}
