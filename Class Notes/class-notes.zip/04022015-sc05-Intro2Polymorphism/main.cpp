#include <iostream>

#include <string>




using namespace std;




class Human

{

public:

    Human();

    virtual string getGender();

private:

    string gender;

};




class Man: public Human

{

public:

    Man();

    string getGender();

private:

    string gender;

};




class Woman: public Human

{

public:

    Woman();

    string getGender();

private:

    string gender;

};




Human::Human()

{

    gender = "neutral";

}




string Human::getGender()

{

    return gender;

}




Man::Man()

{

    gender = "MALE";

}




string Man::getGender()

{

    return gender;

}




Woman::Woman()

{

    gender = "FEMALE";

}




string Woman::getGender()

{

    return gender;

}




int main()

{

    Human *ptrHuman = new Human();

    Human *ptrMan = new Man();

    Human *ptrWoman = new Woman();




    cout << "HUMAN: " << ptrHuman->getGender() << endl;

    cout << "MAN: " << ptrMan->getGender()<< endl;

    cout << "WOMAN: " << ptrWoman->getGender()<< endl;

    return 0;

}
