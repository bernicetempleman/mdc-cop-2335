
#include <iostream>

using namespace std;




int main()

{

    int numbers[] = {10, 20, 30, 40, 50};

  cout << "This is an array of integers: " << numbers << endl;

    cout << "This the 1st location of the array: " << &numbers[0] << endl;

    cout << "This the 1st location of the array: " << &numbers[1] << endl;




    /*

    int *ptr1 = &numbers[0];

    int *ptr2 = &numbers[1];

    int *ptr3 = &numbers[2];

    int *ptr4 = &numbers[3];

    int *ptr5 = &numbers[4];




    cout << *ptr << endl;

    cout << *ptr2 << endl;

    cout << *ptr3 << endl;

    cout << *ptr4 << endl;

    cout << *ptr5 << endl;

    */




    // pointing to the 1st location

    int *ptrNum = numbers;

    int *ptrHead = ptrNum;




    /*

    cout << *(ptrNum + 0) << endl;

    cout << *(ptrNum + 1) << endl;

    cout << *(ptrNum + 2) << endl;

    cout << *(ptrNum + 3) << endl;

    cout << *(ptrNum + 4) << endl;

    */




    for (int i=0; i<5; i++)

    {

        cout << *ptrNum << endl;

        ptrNum++;

    }




    cout << "This is the start of the array" << *ptrHead << endl;

//print in reverse
ptrNum--;

for (int i=0; i<5; i++)
{
    cout << *ptrNum << endl;
    ptrNum--;
}

cout << "This is the start of the array" << *ptrNum <<endl;

}
