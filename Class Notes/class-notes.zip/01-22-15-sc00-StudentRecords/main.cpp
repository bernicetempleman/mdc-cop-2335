#include <iostream>




using namespace std;




const int NUM_QUIZZES = 30;

const int NUM_ASSIGNMENTS = 30;




struct StudentInfo

{

   string   name;

   int      id;

   int      quizzes[NUM_QUIZZES];

   int      assignments[NUM_ASSIGNMENTS];

   int      midterm;

   int      finalExam;

};




// function prototypes

void getStudentData(string &, int &);

StudentInfo getStudentScore(const string &, const int &, const int &, const int & );

void displayStudentData(StudentInfo [], int, int, int );




int main()

{

    int numStudents,

        numAssignments,

        numQuizzes;

    string studentName;

    int studentID;




    cout << "Number of students: ";

    cin >> numStudents;




    cout << "Number of quizzes: ";

    cin >> numQuizzes;




    cout << "Number of assignments: ";

    cin >> numAssignments;




    // there will a CR/LF in the KBD buffer

    cin.ignore();

    cin.sync();







    // declare an array of StudentInfo

    StudentInfo myStudents[numStudents];




    // populate the student array

    for (int i=0; i<numStudents; i++)

    {

        // gather student info

        getStudentData(studentName, studentID);

        myStudents[i] = getStudentScore(studentName, studentID, numQuizzes, numAssignments);

    }




    // Display Data

    displayStudentData(myStudents, numStudents, numQuizzes, numAssignments);




    return 0;

}




void displayStudentData(StudentInfo myClass[], int numS, int numQ, int numA)

{

    for (int i=0; i<numS; i++)

    {

        cout << "Name: " << myClass[i].name << endl;

        cout << "ID: " << myClass[i].id << endl;

        for (int j=0; j<numQ; j++)

        {

            cout << "Quiz #" << j+1 << ":" << myClass[i].quizzes[j] << endl;

        }




        for (int j=0; j<numA; j++)

        {

            cout << "Assignment #" << j+1 << ":" << myClass[i].assignments[j] << endl;

        }




        cout << "Midterm : " << myClass[i].midterm << endl;

        cout << "Final : " << myClass[i].finalExam << endl;

    }

}




StudentInfo getStudentScore(const string &name, const int &id,

                            const int &numQ, const int &numA )

{

    StudentInfo aStudent;

    aStudent.name = name;

    aStudent.id = id;




    // gather quiz scores

    for (int i=0; i<numQ; i++)

    {

        cout << "Quiz #" << i+1 << ":";

        cin >> aStudent.quizzes[i];

    }




    // gather assignment scores

    for (int i=0; i<numA; i++)

    {

        cout << "Quiz #" << i+1 << ":";

        cin >> aStudent.assignments[i];

    }




    cout << "Midterm: ";

    cin >> aStudent.midterm;




    cout << "Final Exam: ";

    cin >> aStudent.finalExam;




    cin.ignore();

    cin.sync();




    return aStudent;

}




void getStudentData(string &name, int &id)

{

    cout << "Name: ";

    getline(cin, name);




    cout << "ID: ";

    cin >> id;




    cin.ignore();

    cin.sync();




}
/*1) prompt the user for # of students

2) For each Student

   prompt the user for student name

   prompt the user for # of quizzes (20%)

   collect quiz scores according to user input

   prompt the user for # of Assignemnts (50%)

   colelct assignment scores for # of quizzes

   prompt the user for the MTE (10%)

   prompt the user for the FE (%20)

3) for each student calculate the average

4) determine the letter grade

5) display student name, score (avg), letter grade
*/
