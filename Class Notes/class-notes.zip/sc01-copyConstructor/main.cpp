#include <iostream>




using namespace std;




class MyLine

{

public:

    MyLine(int l);   // regular/overriden constructor

    MyLine(const MyLine &anotherLine);  // example of a copy constructor

    ~MyLine();




    // getter

    int getLineLength();




    // utility

    void display();

private:

    int *ptrLength;




};




MyLine::MyLine(int l)

{

   cout << "In constructor" << endl;

   ptrLength = new int;

   *ptrLength = l;

}




MyLine::MyLine(const MyLine &anotherLine)

{

   cout << "In copy constructor" << endl;

   ptrLength = new int;

   *ptrLength = *anotherLine.ptrLength;

}




MyLine::~MyLine()

{

    cout << "In destructor" << endl;

    delete ptrLength;

}




int MyLine::getLineLength()

{

   return *ptrLength;

}




void MyLine::display()

{

    cout << "Line length is: "<< getLineLength() << endl;

}




int main()

{

    MyLine line1(10);

    //MyLine line2 = line1;

    MyLine line2(line1);




    line1.display();

    line2.display();

    return 0;

}
