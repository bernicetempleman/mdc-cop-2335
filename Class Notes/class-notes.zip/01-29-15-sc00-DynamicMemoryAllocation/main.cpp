#include <iostream>




using namespace std;




int main()

{

    int *ptrX = new int();  // dynamically allocating memory




    *ptrX = 100;




    cout << "this is ptrX : "  << *ptrX << endl;

    cout << "this is the address ofd ptrX : "  << ptrX << endl;




    // deallocate (delete) the memory

    delete ptrX;

    cout << "The contents of ptrX : " << *ptrX << endl;

    ptrX = NULL;

    //cout << "The contents of ptrX : " << *ptrX << endl;




    return 0;

}


