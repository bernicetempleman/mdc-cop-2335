#include <iostream>

using namespace std;

struct MovieData
{
    string title;
    string director;
    string year;
    int time;
};

void getMovie(MovieData &);
void displayMovie(const MovieData &);

int main()
{
    MovieData movie1;
    MovieData movie2;

    getMovie(movie1);
    displayMovie(movie1);

    cout << "Hello world!" << endl;
    return 0;
}

void getMovie(MovieData &m)
{
    cout << "enter title: ";
    getline(cin, m.title);
}
void displayMovie(const MovieData &m)
{
    cout <<m.title<< endl;
}
