#include <iostream>

#include <fstream>

#include <cstdlib>




using namespace std;




const int CIPHER = 5;




int main()

{
/*
    ifstream inFile;

    ofstream outFile;




    outFile.open("Cipher.txt");




    inFile.open("SampleText.txt");

    if (!inFile)

    {

        cout << "Trouble locating the input file. Exiting..." << endl;

        exit(1);

    }




    // read from the input file

    char ch;

    while (inFile >> ch)

    {

        ch = ch + CIPHER;

        outFile << ch;

    }




    inFile.close();
    if (!inFile)

    {

        cout << "Trouble locating the input file. Exiting..." << endl;

        exit(1);

    }

    outFile.close();

    inFile.open("Cipher.txt");

    while (inFile >> ch)

    {

        ch = ch + CIPHER;

        cout << ch;

    }




    return 0;

}
/********************************************/
    ifstream d;

    ofstream d2;




    outFile.open("Cipher.txt");




    inFile.open("SampleText.txt");

    if (!inFile)

    {

        cout << "Trouble locating the input file. Exiting..." << endl;

        exit(1);

    }




    // read from the input file

    char ch;

    while ((ch=inFile.get())!=string::npos)

    {

        ch = ch + CIPHER;

        outFile<<ch;

    }

    d.open("Cipher.txt");

    d2.open("d.txt");

    char ch2;

    while ((ch2=d.get())!=string::npos)

    {

        ch2 = ch2 - CIPHER;

        d2<<ch2;

    }

    d.close();

    inFile.close();

    outFile.close();

    d2.close();




    return 0;

}
