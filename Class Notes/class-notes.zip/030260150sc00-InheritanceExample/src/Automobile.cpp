#include "Automobile.h"

#include <iostream>




Automobile::Automobile()

{

    //ctor

    cout << "In AUTOMOBILE constructor" << endl;

}







Automobile::Automobile(string mk, string md, int ml, double m, int y)

{

    cout << "in Automobile overriden constructor" << endl;

    make = mk;

    model = md;

    mileage = ml;

    mpg = m;

    yearMade = y;

}




Automobile::~Automobile()

{

    cout << "In AUTOMOBILE destructor" << endl;

}
