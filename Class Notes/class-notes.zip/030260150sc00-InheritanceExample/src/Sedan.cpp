#include "Sedan.h"




Sedan::Sedan()

{

   cout << "In SEDAN constructor" << endl;

}







Sedan::Sedan(int i,

             string mk,string md,int ml,double m, int y):

    Automobile(mk, md,ml,m,y)

{

    cout << "In SEDAN overriden constructor" << endl;

    numDoors = i;

}







Sedan::~Sedan()

{

    cout << "In SEDAN destructor" << endl;

}
