#include <iostream>

#include "Sedan.h"




using namespace std;




int main()

{

    Sedan *mySedan = new Sedan(4,"BMW", "M5",10000,24.5,2014);

    cout << "Make: " << mySedan->Getmake() << endl;

    cout << "Model: " << mySedan->Getmodel() << endl;

    cout << "Miles: " << mySedan->Getmileage() << endl;

    cout << "MPG: " << mySedan->Getmpg() << endl;

    cout << "Year Made: " << mySedan->GetyearMade() << endl;

    return 0;

}
