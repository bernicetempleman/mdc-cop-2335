#ifndef AUTOMOBILE_H

#define AUTOMOBILE_H




#include <string>




using namespace std;




class Automobile

{

    public:

        Automobile();

        Automobile(string mk, string md, int ml, double mpg, int y);

        ~Automobile();




        string Getmake() { return make; }

        void Setmake(string val) { make = val; }

        string Getmodel() { return model; }

        void Setmodel(string val) { model = val; }

        int Getmileage() { return mileage; }

        void Setmileage(int val) { mileage = val; }

        double Getmpg() { return mpg; }

        void Setmpg(double val) { mpg = val; }

        int GetyearMade() { return yearMade; }

        void SetyearMade(int val) { yearMade = val; }

    protected:

    private:

        string make;

        string model;

        int mileage;

        double mpg;

        int yearMade;

};




#endif // AUTOMOBILE_H
