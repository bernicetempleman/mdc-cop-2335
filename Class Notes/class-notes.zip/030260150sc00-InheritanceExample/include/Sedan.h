#ifndef SEDAN_H

#define SEDAN_H




#include <Automobile.h>

#include <iostream>




using namespace std;




class Sedan : public Automobile

{

    public:

        Sedan();

        Sedan(int i,string mk, string md, int ml, double mpg, int y);

        ~Sedan();

    protected:

    private:

        int numDoors;

};




#endif // SEDAN_H
