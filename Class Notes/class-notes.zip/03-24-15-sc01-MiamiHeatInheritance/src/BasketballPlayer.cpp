#include "BasketballPlayer.h"

BasketballPlayer::BasketballPlayer()
{
    //ctor
}

BasketballPlayer::~BasketballPlayer()
{
    //dtor
}
