#include "Person.h"

Person::Person()
{
    //ctor
}

Person::~Person()
{
    //dtor
}
