#ifndef PERSON_H
#define PERSON_H


class Person
{
    public:
        Person();
        ~Person();
        string Getname() { return name; }
        void Setname(string val) { name = val; }
    protected:
    private:
        string name;
};

#endif // PERSON_H
