#ifndef BASKETBALLPLAYER_H
#define BASKETBALLPLAYER_H

#include <Person.h>


class BasketballPlayer : public Person
{
    public:
        BasketballPlayer();
        ~BasketballPlayer();
        double Getppg() { return ppg; }
        void Setppg(double val) { ppg = val; }
    protected:
    private:
        double ppg;
};

#endif // BASKETBALLPLAYER_H
