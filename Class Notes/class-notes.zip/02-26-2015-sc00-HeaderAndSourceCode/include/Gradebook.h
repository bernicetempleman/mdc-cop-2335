#ifndef GRADEBOOK_H

#define GRADEBOOK_H




#include <iostream>




using namespace std;




class Gradebook

{

    public:

        Gradebook();



        Gradebook(string cName,

                  string cAbbr,

                  int    cRef);

        ~Gradebook();

        //default
        Gradebook(courseName=NULL,
                  courseAbbr = NULL,
                  courseRef = 0);

        ~Gradebook();




        // getters and setters

        string getCourseName() { return courseName;}

        void setCourseName(string val) {courseName = val; }

        string getCourseAbbr() { return courseAbbr; }

        void setCourseAbbr(string val) { courseAbbr = val; }

        int getCourseRef() { return courseRef; }

        void setCourseRef(int val) { courseRef = val; }




        // utility function

        void displayMessage();




    private:

        string courseName;

        string courseAbbr;

        int courseRef;

};




#endif // GRADEBOOK_H
