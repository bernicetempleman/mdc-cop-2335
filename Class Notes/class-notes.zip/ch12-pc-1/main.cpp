
// ask user for name of file
// display the first 10 lines of the file
// if all lines displayed, display a message
//"The entire file has been displayed"

#include <iostream>
#include <fstream>
#include <string>
#include <cstring>


using namespace std;

int main()
{

    string filename;

    cout << "enter a file name: ";
    getline(cin, filename);

    std::fstream outfile;

    outfile.open(filename.c_str(), ios::out);

        //read in lines from cin

        char userChoice ='y';
        string inputline;
        while (userChoice != 'n')
        {
            cout <<"enter a line:";
            cin>>inputline;
            outfile << inputline <<'\n' ;


            cout <<"continue: y or n ";
            cin >> userChoice;
        }


    outfile.close();

    fstream infile;
    infile.open(filename.c_str(), ios::in);

    getline(infile, inputline);
    int i = 0;

    while((infile) && (i < 10))
    {
        cout << inputline << endl;

        i++;
        getline(infile, inputline);


    }
    if (i <11)
            cout <<"entire file read"<<endl;


    infile.close();

    return 0;
}
