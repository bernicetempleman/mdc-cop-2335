#ifndef GRADEBOOK_H

#define GRADEBOOK_H







class GradeBook

{

    public:

        GradeBook();

        ~GradeBook();

        string getCourseName() { return m_courseName; }

        void setCourseName(string val) { m_courseName = val; }

        string getCourseAbbr() { return m_courseAbbr; }

        void setCourseAbbr(string val) { m_courseAbbr = val; }

        int getCourseRef() { return m_courseRef; }

        void setCourseRef(int val) { m_courseRef = val; }

    protected:

    private:

        string m_courseName;

        string m_courseAbbr;

        int m_courseRef;

};




#endif // GRADEBOOK_H








