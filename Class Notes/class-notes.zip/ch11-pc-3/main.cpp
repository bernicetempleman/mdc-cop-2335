#include <iostream>

using namespace std;

const int SALES_NUM = 4;
const int DIVISION_NUM = 4;

struct Division
{
    string name;
    double sales[SALES_NUM];
    double total;
    double average;
};

void getSales(Division [], int,int);
void display(const Division [], int,int);
void calcTotal(Division [], int,int);
void calcAvg(Division [], int,int);

int main()
{
    Division d[DIVISION_NUM];

    d[0].name = "East";
    d[1].name ="West";
    d[2].name = "North";
    d[3].name ="South";

    getSales(d,DIVISION_NUM,SALES_NUM);

    calcTotal(d,DIVISION_NUM,SALES_NUM);

    calcAvg(d,DIVISION_NUM,SALES_NUM);

    display(d,DIVISION_NUM,SALES_NUM);

    return 0;
}

void getSales(Division d[], int dnum, int snum)
{
    double tempSales;

    for(int i = 0; i <dnum; i++)
    {
        cout << "Enter sales for Division: " << d[i].name << ": " <<endl;

        for(int j=0; j<snum; j++)
        {
            cout << "Quarter "<< j+1<< ": ";
            cin >> tempSales;

            if (tempSales >= 0)
                d[i].sales[j] = tempSales;
            else
            {
                do
                {
                    cout << "SALES CAN NOT BE NEGATIVE"<< endl;
                    cout << "Quarter "<< j+1<< ": ";
                    cin >> tempSales;
                }while(tempSales < 0);
                d[i].sales[j] = tempSales;
            }
        }
    }
}

void display(const Division d[], int dnum,int snum)
{
    for(int i = 0; i <dnum; i++)
    {
        cout << "Sales for Division: " << d[i].name << ": " <<endl;

        for(int j=0; j<snum; j++)
        {
            cout << "Quarter "<< j+1<< ": " << d[i].sales[j] << endl;
        }
        cout << "Total: " << d[i].total << endl;
        cout << "Average: " << d[i].average << endl;
    }
}

void calcTotal(Division d[], int dnum, int snum)
{

    for(int i = 0; i <dnum; i++)
    {
        d[i].total = 0.0;
        for(int j=0; j<snum; j++)
        {
            d[i].total = d[i].total + d[i].sales[j];
        }
    }
}

void calcAvg(Division d[], int dnum,int snum)
{
    for(int i = 0; i <dnum; i++)
    {
        d[i].average = d[i].total / snum;
    }
}
