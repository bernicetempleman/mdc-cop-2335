#include "Student.h"


#include <iostream>

Student::Student()
{
    //ctor
}

Student::Student( string mjr, double gp, string yr, string nm, string db):
    Person(nm,db)
{
    major = mjr;
    gpa = gp;
    year =  yr;
}

Student::~Student()
{
    //dtor
}

/*
Sedan::Sedan(int i,

             string mk,string md,int ml,double m, int y):

    Automobile(mk, md,ml,m,y)

{

    cout << "In SEDAN overriden constructor" << endl;

    numDoors = i;

}
*/
