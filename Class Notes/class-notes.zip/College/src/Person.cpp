#include "Person.h"

#include <iostream>

Person::Person()
{
    //ctor
}

Person::Person(string nm, string db)
{
    name = nm;
    dob = db;
}

Person::~Person()
{
    //dtor
}

/*Automobile::Automobile(string mk, string md, int ml, double m, int y)

{

    cout << "in Automobile overriden constructor" << endl;

    make = mk;

    model = md;

    mileage = ml;

    mpg = m;

    yearMade = y;

}
*/
