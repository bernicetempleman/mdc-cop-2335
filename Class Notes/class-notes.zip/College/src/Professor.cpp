#include "Professor.h"


using namespace std;

Professor::Professor()
{
    //ctor
}

Professor::Professor( string fld, string pos, string nm, string db):
    Person(nm,db)
{
    field = fld;
    position = pos;

}

Professor::~Professor()
{
    //dtor
}
