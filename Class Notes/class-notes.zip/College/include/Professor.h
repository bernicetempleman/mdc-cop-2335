#ifndef PROFESSOR_H
#define PROFESSOR_H

#include <Person.h>

#include <iostream>

class Professor : public Person
{
    public:
        Professor();
        Professor( string fld, string pos, string nm, string db);
        ~Professor();
        string Getfield() { return field; }
        void Setfield(string val) { field = val; }
        string Getposition() { return position; }
        void Setposition(string val) { position = val; }
    protected:
    private:
        string field;
        string position;
};

#endif // PROFESSOR_H
