#ifndef STUDENT_H
#define STUDENT_H

#include <Person.h>

#include <iostream>

class Student : public Person
{
    public:
        Student();
        Student( string mjr, double gp, string yr, string nm, string db);
        ~Student();
        string Getmajor() { return major; }
        void Setmajor(string val) { major = val; }
        double Getgpa() { return gpa; }
        void Setgpa(double val) { gpa = val; }
        string Getyear() { return year; }
        void Setyear(string val) { year = val; }
    protected:
    private:
        string major;
        double gpa;
        string year;
};

#endif // STUDENT_H
