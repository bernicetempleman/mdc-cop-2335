#ifndef PERSON_H
#define PERSON_H
#include <string>


using namespace std;

class Person
{
    public:
        Person();
        //Automobile(string mk, string md, int ml, double mpg, int y);
        Person(string nm, string db);
        ~Person();

        string Getname() { return name; }
        void Setname(string val) { name = val; }
        string Getdob() { return dob; }
        void Setdob(string val) { dob = val; }
    protected:
    private:
        string name;
        string dob;
};

#endif // PERSON_H
