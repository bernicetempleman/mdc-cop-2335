#include <iostream>
#include <string>

#include "Professor.h"
#include "Student.h"

using namespace std;

int main()
{
    cout << "Hello world!" << endl;

    //create student
    Student *myStudent = new Student("CS", 4.0, "Senior","xxxx","01012000");

    cout << "Major: " << myStudent->Getmajor() <<endl;

    Professor  *myProfessor = new Professor("CS", "FullTime", "Prof", "02022000");
    cout << "Field: " << myProfessor->Getfield() <<endl;

    delete myStudent;
    delete myProfessor;

    //create professor

    return 0;

    /*
        Sedan *mySedan = new Sedan(4,"BMW", "M5",10000,24.5,2014);

    cout << "Make: " << mySedan->Getmake() << endl;

    cout << "Model: " << mySedan->Getmodel() << endl;

    cout << "Miles: " << mySedan->Getmileage() << endl;

    cout << "MPG: " << mySedan->Getmpg() << endl;

    cout << "Year Made: " << mySedan->GetyearMade() << endl;
    */
}
