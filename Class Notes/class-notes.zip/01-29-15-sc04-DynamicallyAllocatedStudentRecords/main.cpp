#include <iostream>

#include <cstdlib>




using namespace std;




const double FINAL_EXAM_WT = 0.10;

const double MTE_EXAM_WT = 0.05;

const double PE_WT = 0.50;

const double QUIZ_WT = 0.35;

struct StudentInfo

{

    int studentID;

    string name;

    int *ptrProgExercises;

    int *ptrQuizzes;

    int midterm;

    int finalExam;

    double totalScore;

    char letterGrade;

};




// prototypes

void getStudentInfo(StudentInfo *,int,int,int);

double calculateFinalScore(double , double , int , int );

char assignLetterGrade(double );

void displayStudentRecords(StudentInfo *,int);







int main()

{

    StudentInfo *ptrMyClass;

    int numStudents,

        numQuizzes,

        numExercises;




    cout << "Number of students in your class: ";

    cin >> numStudents;




    ptrMyClass = new StudentInfo[numStudents];




    // safe programming practice

    if (!ptrMyClass)

    {

        cout << "Unable to successfully allocate required memory...";

        cout << "Exiting...";

        system ("PAUSE");   // Windows only
#include <iostream>

#include <cstdlib>




using namespace std;




const double FINAL_EXAM_WT = 0.10;

const double MTE_EXAM_WT = 0.05;

const double PE_WT = 0.50;

const double QUIZ_WT = 0.35;

struct StudentInfo

{

    int studentID;

    string name;

    int *ptrProgExercises;

    int *ptrQuizzes;

    int midterm;

    int finalExam;

    double totalScore;

    char letterGrade;

};




// prototypes

void getStudentInfo(StudentInfo *,int,int,int);

double calculateFinalScore(double , double , int , int );

char assignLetterGrade(double );

void displayStudentRecords(StudentInfo *,int);







int mein()

{

    StudentInfo *ptrMyClass;

    int numStudents,

        numQuizzes,

        numExercises;




    cout << "Number of students in your class: ";

    cin >> numStudents;




    ptrMyClass = new StudentInfo[numStudents];




    // safe programming practice

    if (!ptrMyClass)

    {

        cout << "Unable to successfully allocate required memory...";

        cout << "Exiting...";

        system ("PAUSE");   // Windows only

        exit(0);

    }




    // we know we have a good pointer, so we code the logic here..

    // get student info

    cout << "Number of quizzes: ";

    cin >> numQuizzes;




    cout << "Number of progEx: ";

    cin >> numExercises;

    getStudentInfo(ptrMyClass, numStudents, numExercises, numQuizzes);




    // display student records

    displayStudentRecords(ptrMyClass, numStudents);







    // deallocate the memory

    StudentInfo* ptrStudent;

    for (int i=0; i<numStudents; i++)

    {

        ptrStudent = &ptrMyClass[i];

        delete []ptrStudent->ptrQuizzes;

        delete []ptrStudent->ptrProgExercises;

    }

    delete []ptrMyClass;




    return 0;

}




double calculateFinalScore(double quizScore,

                           double progExScore,

                           int midTermScore,

                           int finalExamScore)

{




   // double finalScore;




    return (quizScore*QUIZ_WT) +

                 (progExScore*PE_WT) +

                 (midTermScore*MTE_EXAM_WT) +

                 (finalExamScore * FINAL_EXAM_WT);




    // return finalScore;

}




void getStudentInfo(StudentInfo *ptrMyStudents,

                    int numStudents,

                    int numProgEx,

                    int numQuizzes)

{

     StudentInfo *ptrStudent;  // one structure

     int progExSum,

         quizSum;




     double progExAvg,

            quizAvg;




     for (int i=0; i<numStudents; i++)

     {

         ptrStudent = &ptrMyStudents[i];  // pointing to the first location

                                          // in the array

         cout << "Student " << i+1 << " ID: ";

         cin >> ptrStudent->studentID;




         cin.ignore();

         cin.sync();




         cout << "Student " << i+1 << " Name: ";

         getline(cin, ptrStudent->name);




         // dynamically allocate memory for exercises

         ptrStudent->ptrProgExercises = new int[numProgEx];




         progExSum = 0;   // initialize inside the loop bcs you need to

                          //  reset for each student




         // populate progEx array

         for (int j=0; j<numProgEx; j++)

         {

             cout << "progEx " << j+1 << " score: ";

             cin >> ptrStudent->ptrProgExercises[j];

             progExSum = progExSum + ptrStudent->ptrProgExercises[j];

         }




         // compute the average for the category

         progExAvg = progExSum/static_cast<double>(numProgEx);




         // dynamically allocate memory for quizzes

         ptrStudent->ptrQuizzes = new int[numQuizzes];

         quizSum = 0;   // initialize inside the loop bcs you need to

                          //  reset for each student




         // populate quizzes array

         for (int j=0; j<numQuizzes; j++)

         {

             cout << "Quiz " << j+1 << " score: ";

             cin >> ptrStudent->ptrQuizzes[j];

             quizSum += ptrStudent->ptrQuizzes[j];

         }




         // compute the average for the category

         quizAvg = quizSum/static_cast<double>(numQuizzes);




         // mte

         cout << "Student " << i+1 << " Midterm: ";

         cin >> ptrStudent->midterm;




         // fe

         cout << "Student " << i+1 << " Final: ";

         cin >> ptrStudent->finalExam;




         // calculate the total score

         ptrStudent->totalScore = calculateFinalScore(quizAvg,

                                        progExAvg,

                                        ptrStudent->midterm,

                                        ptrStudent->finalExam);




         // determine the letter grade

         ptrStudent->letterGrade = assignLetterGrade(ptrStudent->totalScore);




     }




}




void displayStudentRecords(StudentInfo *ptrMyStudents,

                           int          numStudents)

{

    StudentInfo* ptrStudent;

    for (int i=0; i<numStudents; i++)

    {

         ptrStudent = &ptrMyStudents[i];  // pointing to the first location

                                          // in the array

         cout << "Student " << i+1 << " ID: "

              << ptrStudent->studentID

              << endl;




         cout << "Student " << i+1 << " Name: "

              << ptrStudent->name

              << endl;




         cout << "Student " << i+1 << " Total Score: "

              << ptrStudent->totalScore

              << endl;

         cout << "Student " << i+1 << " Letter: "

              << ptrStudent->letterGrade

              << endl;

         cout << "========================================" << endl;

    }




}

char assignLetterGrade(double totalScore)

{

    char letterGrade;

    if (totalScore >89)

    {

       letterGrade = 'A';

    }

    else if (totalScore > 79)

    {

        letterGrade = 'B';

    }

    else if (totalScore > 69)

    {

        letterGrade = 'C';

    }

    else if (totalScore > 59)

    {

        letterGrade = 'D';

    }

    else

    {

        letterGrade = 'F';

    }




    return letterGrade;

}
        exit(0);

    }




    // we know we have a good pointer, so we code the logic here..

    // get student info

    cout << "Number of quizzes: ";

    cin >> numQuizzes;




    cout << "Number of progEx: ";

    cin >> numExercises;

    getStudentInfo(ptrMyClass, numStudents, numExercises, numQuizzes);




    // display student records

    displayStudentRecords(ptrMyClass, numStudents);







    // deallocate the memory

    StudentInfo* ptrStudent;

    for (int i=0; i<numStudents; i++)

    {

        ptrStudent = &ptrMyClass[i];

        delete []ptrStudent->ptrQuizzes;

        delete []ptrStudent->ptrProgExercises;

    }

    delete []ptrMyClass;




    return 0;

}




double calculateFinalScore(double quizScore,

                           double progExScore,

                           int midTermScore,

                           int finalExamScore)

{




   // double finalScore;




    return (quizScore*QUIZ_WT) +

                 (progExScore*PE_WT) +

                 (midTermScore*MTE_EXAM_WT) +

                 (finalExamScore * FINAL_EXAM_WT);




    // return finalScore;

}




void getStudentInfo(StudentInfo *ptrMyStudents,

                    int numStudents,

                    int numProgEx,

                    int numQuizzes)

{

     StudentInfo *ptrStudent;  // one structure

     int progExSum,

         quizSum;




     double progExAvg,

            quizAvg;




     for (int i=0; i<numStudents; i++)

     {

         ptrStudent = &ptrMyStudents[i];  // pointing to the first location

                                          // in the array

         cout << "Student " << i+1 << " ID: ";

         cin >> ptrStudent->studentID;




         cin.ignore();

         cin.sync();




         cout << "Student " << i+1 << " Name: ";

         getline(cin, ptrStudent->name);




         // dynamically allocate memory for exercises

         ptrStudent->ptrProgExercises = new int[numProgEx];




         progExSum = 0;   // initialize inside the loop bcs you need to

                          //  reset for each student




         // populate progEx array

         for (int j=0; j<numProgEx; j++)

         {

             cout << "progEx " << j+1 << " score: ";

             cin >> ptrStudent->ptrProgExercises[j];

             progExSum = progExSum + ptrStudent->ptrProgExercises[j];

         }




         // compute the average for the category

         progExAvg = progExSum/static_cast<double>(numProgEx);




         // dynamically allocate memory for quizzes

         ptrStudent->ptrQuizzes = new int[numQuizzes];

         quizSum = 0;   // initialize inside the loop bcs you need to

                          //  reset for each student




         // populate quizzes array

         for (int j=0; j<numQuizzes; j++)

         {

             cout << "Quiz " << j+1 << " score: ";

             cin >> ptrStudent->ptrQuizzes[j];

             quizSum += ptrStudent->ptrQuizzes[j];

         }




         // compute the average for the category

         quizAvg = quizSum/static_cast<double>(numQuizzes);




         // mte

         cout << "Student " << i+1 << " Midterm: ";

         cin >> ptrStudent->midterm;




         // fe

         cout << "Student " << i+1 << " Final: ";

         cin >> ptrStudent->finalExam;




         // calculate the total score

         ptrStudent->totalScore = calculateFinalScore(quizAvg,

                                        progExAvg,

                                        ptrStudent->midterm,

                                        ptrStudent->finalExam);




         // determine the letter grade

         ptrStudent->letterGrade = assignLetterGrade(ptrStudent->totalScore);




     }




}




void displayStudentRecords(StudentInfo *ptrMyStudents,

                           int          numStudents)

{

    StudentInfo* ptrStudent;

    for (int i=0; i<numStudents; i++)

    {

         ptrStudent = &ptrMyStudents[i];  // pointing to the first location

                                          // in the array

         cout << "Student " << i+1 << " ID: "

              << ptrStudent->studentID

              << endl;




         cout << "Student " << i+1 << " Name: "

              << ptrStudent->name

              << endl;




         cout << "Student " << i+1 << " Total Score: "

              << ptrStudent->totalScore

              << endl;

         cout << "Student " << i+1 << " Letter: "

              << ptrStudent->letterGrade

              << endl;

         cout << "========================================" << endl;

    }




}

char assignLetterGrade(double totalScore)

{

    char letterGrade;

    if (totalScore >89)

    {

       letterGrade = 'A';

    }

    else if (totalScore > 79)

    {

        letterGrade = 'B';

    }

    else if (totalScore > 69)

    {

        letterGrade = 'C';

    }

    else if (totalScore > 59)

    {

        letterGrade = 'D';

    }

    else

    {

        letterGrade = 'F';

    }




    return letterGrade;

}
