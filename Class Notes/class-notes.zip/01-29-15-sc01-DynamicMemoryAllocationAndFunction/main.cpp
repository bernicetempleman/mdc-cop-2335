include <iostream>


using namespace std;




// function prototype

int *getMiamiTemperatures(int );

void displayTemperatures(const int *, int );

double getAverageTemp(const int *, int );

int main()

{

    const int NUM_MONTHS = 12;

    int *ptrMiamiTemps;  // pointer to an array of temps

    ptrMiamiTemps = getMiamiTemperatures(NUM_MONTHS);




    // display the contents of the array

    displayTemperatures(ptrMiamiTemps, NUM_MONTHS);




    cout << "Miami avg temp is : " << getAverageTemp(ptrMiamiTemps,NUM_MONTHS)

         << endl;




    // deallocate the memory

    delete []ptrMiamiTemps;

    ptrMiamiTemps = NULL;

    return 0;

}




double getAverageTemp(const int *ptrTemp, int numMonths)

{

    int sum = 0;   // accumulator

    double avg;




    for (int i=0; i< numMonths; i++)

    {

        sum = sum + ptrTemp[i];

    }




    avg = static_cast<double>(sum)/numMonths;




    return avg;

}




int *getMiamiTemperatures(int numMonths)

{

    // dynamicaly allocate an array to accomodate temps

    int *myTemps = new int[numMonths];




    // populate w data

    for (int i=0; i< numMonths; i++)

    {

        cout << "Month " << i+1 << " temperature: ";

        cin >> myTemps[i];

    }




    return myTemps;

}




void displayTemperatures(const int *ptrTemps, int numMonths)

{

    // display data

    for (int i=0; i< numMonths; i++)

    {

        cout << "Month " << i+1 << " temperature: "

             << ptrTemps[i]  << endl;

    }




}





