#include <iostream>




using namespace std;




class MyLine

{

public:

    MyLine(int l);

    ~MyLine();




    // getter

    int getLineLength();




    // utility

    void display();

private:

    int lineLength;




};




MyLine::MyLine(int l)

{

   cout << "In constructor" << endl;

   lineLength = l;

}




MyLine::~MyLine()

{

    cout << "In destructor" << endl;

}




int MyLine::getLineLength()

{

   return lineLength;

}




void MyLine::display()

{

    cout << "Line length is: "<< getLineLength() << endl;

}




int main()

{

    MyLine line1(10);

    MyLine line2 = line1;




    line1.display();

    line2.display();

    return 0;

}
