#include <iostream>
#include <cmath>
#include <iomanip>
#include <string>

using namespace std;

const double PI = 3.14159;

struct Circle
{

    double radius;
    double diameter;
    double area;
};

Circle getInfo();

int main()
{
    Circle c;

    Circle *circles;
    circles = new Circle[5];

    c = getInfo();

    c.area = PI * pow(c.radius, 2.0);

    cout << fixed << setprecision(2);
    cout << "Radius: " << c.radius << endl;
    cout << "Area: " << c.area << endl;

    cout << " circles arry: "<< endl;
    for (int i =0; i < 5; i++)
    {
        cout << "Enter the radius for the circle "
        << i + 1 << " : ";
        cin >> circles[i].radius;
    }

    for (int i =0; i < 5; i++)
    {
      cout << "circles "<< i << " radius :"
      <<   circles[i].radius << endl;
    }


    return 0;
}

Circle getInfo()
{
    Circle tempCircle;

    cout << "Enter the diameter of a circle: ";
    cin >> tempCircle.diameter;

    tempCircle.radius = tempCircle.diameter /2.0;

    return tempCircle;

}
