#include <iostream>

using namespace std;

int main()
{
    int a = 10;
    int b = 20;

    int *ptrA;
    int *ptrB;
    int *ptrC;

    ptrA = &a;
    ptrB = &b;
    ptrC = ptrA;   // ptrC = &a;

    cout << "contents of a: " << *ptrC << endl;
    ptrC = ptrB;
    cout << "the contents of what ptrC points to : " << *ptrC << endl;

    // comparison of addresses
    if (ptrB == ptrC)
        cout << "THEY POINT TO THE SAME THING" << endl;
    *ptrB = 10001;
    if (*ptrA == *ptrB)
        cout << "THEY HAVE THE SAME VALUE" << endl;

    return 0;
}
