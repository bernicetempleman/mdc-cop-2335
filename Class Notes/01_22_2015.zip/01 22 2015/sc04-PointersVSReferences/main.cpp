#include <iostream>

using namespace std;

int main()
{
    cout << "-------------- R E F E R E N C E --------------------" << endl;
    int x = 10;
    int &refX = x;
    cout << "Address of variable x: " << &x << endl;
    cout << "contents of variable x: " << x << endl;
    cout << "Address of variable refX: " << &refX << endl;
    cout << "contents of variable refX: " << refX << endl;

    int number = -1;
    refX = number;

    cout << "this is x: " << x << endl;



    cout << "-------------- P O I N T E R --------------------" << endl;
    int y = 1000;
    int *ptrY = &y;
    cout << "Address of variable y: " << ptrY << endl;
    cout << "contents of variable y: " << *ptrY << endl;
    cout << "contents of variable y: " << y << endl;
    cout << "Address of variable ptrY: " << &ptrY << endl;
    cout << "contents of where ptrY points to: " << *ptrY << endl;

    int number2 = -100;
    ptrY = &number2;

    cout << "the contents of y : " << y << endl;
    cout << "the contents of mem location where ptrY points to: " << *ptrY << endl;
    return 0;
}
