#include <iostream>

using namespace std;

int main()
{
    int number;
    number = 105;

    cout << "This is the value stored in number: "
         << number
         << endl;

    // not a reference, denotes address of memory location
    cout << "This is the address of the variable number: "
         << &number
         << endl;

    int *ptrNum;  // declared a pointer

    ptrNum = &number;
    cout << "This is the address of the variable ptrNum: "
         << &ptrNum
         << endl;

    cout << "This is the where ptrNum points to: "
         << ptrNum
         << endl;

    // DE-REFERNCING (*) the pointer variable
    cout << "This is the contents of the variable number (through the pointer): "
         << *ptrNum
         << endl;


    *ptrNum = 1001;

    cout << "The contents of number are: " << number << endl;

    // --- DO NOT DO THIS!!!!!! ------
    int *p;   // pointer
    *p = 10;


    return 0;
}
