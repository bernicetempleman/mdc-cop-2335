#include <iostream>

using namespace std;


// function prototypes
void swapValues(int &, int &);
void swapValues(int *, int *);

int main()
{
    int valA = 10,
        valB = 20;

    cout << "----USING REFERENCES-----" << endl;
    cout << "valA BEFORE the function call : " << valA << endl;
    cout << "valB BEFORE the function call : " << valB << endl;
    swapValues(valA, valB);
    cout << "valA AFTER the function call : " << valA << endl;
    cout << "valB AFTER the function call : " << valB << endl;

    cout << "----USING pointers-----" << endl;
    cout << "valA BEFORE the function call : " << valA << endl;
    cout << "valB BEFORE the function call : " << valB << endl;
    swapValues(&valA, &valB);
    cout << "valA AFTER the function call : " << valA << endl;
    cout << "valB AFTER the function call : " << valB << endl;
    return 0;
}

void swapValues(int &x, int &y)
{
    int temp;
    temp = x;
    x = y;
    y = temp;
}

void swapValues(int *pX, int *pY)
{
    int temp;
    temp = *pX;
    *pX = *pY;
    *pY = temp;
}

