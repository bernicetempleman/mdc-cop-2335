#include <iostream>
#include <cstring>
#include <cstdlib>

using namespace std;

const int SIZE = 35;

struct Entry
{
    char name[SIZE];
    int  id;
    Entry* next;
};

// function prototypes
Entry* getNewEntry();
bool addFirst(Entry* , Entry* &);

int main()
{
    cout << "Hello world!" << endl;
    return 0;
}

Entry* buildList()
{
    Entry *listHead = NULL;
    while(true)
    {
        // allocate a new node
        Entry* newOne  = getNewEntry();
        if (!addFirst(newOne,listHead ))
            break;
    }

    return listHead;
}

Entry* getNewEntry()
{
    char name[SIZE];

    cout << "Enter a name (press ENTER to quit):";
    cin.getline(name, SIZE);

    // check if they pressed the ENTER key
    if (strlen(name)==0)
    {
        cout << "Thank you for your input" << endl;
        return NULL;
    }

    Entry* newOne = new Entry;
    strcpy(newOne->name, name);
    cout << "ID: ";
    cin >> newOne->id;
    cin.ignore();
    cin.sync();
    return newOne;
}

bool addFirst(Entry* newEntry, Entry* &head)
{
    if (newEntry == NULL)
        return false;

    // wire the pointers
    newEntry->next = head;
    head = newEntry;
    return true;
}
