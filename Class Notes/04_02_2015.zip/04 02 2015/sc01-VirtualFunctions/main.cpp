#include <iostream>
#include <string>

using namespace std;


// base class
class PetType
{
public:
    PetType(string n="");
    virtual void print();
private:
    string name;
};

class DogType : public PetType
{
public:
    DogType(string n="",string b="");
    void print();
private:
    string breed;
};

PetType::PetType(string n)
{
    cout << "in PetType constructor" << endl;
    name = n;
}

void PetType::print()
{
    cout << "in PetType::print ";
    cout << "Name: " << name << endl;
}

DogType::DogType(string name, string breed):PetType(name)
{
    cout << "in DogType constructor" << endl;
    this->breed = breed;
}

void DogType::print()
{
    PetType::print();
    cout << "in DogType::print ";
    cout << "Breed: " << breed << endl;
}

// function prototypes
void callPrint(PetType &);

int main()
{
    //PetType pet("Lucky");
    DogType dog("Butch", "German Shepherd");

    //pet.print();
    //dog.print();

    cout << "Calling callPrint function" << endl;
    //callPrint(pet);
    callPrint(dog);
    return 0;
}

void callPrint(PetType &p)
{
    p.print();
}
