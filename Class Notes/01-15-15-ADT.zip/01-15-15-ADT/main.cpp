#include <iostream>

using namespace std;

struct CarEngine
{

    double displacement;

    int    numberOfCylinders;

    int    horsePower;

};




struct CarInfo

{

   string make;

   string model;

   CarEngine engine;

   int    year;

   double mpg;

};




// function prototypes

void displayCarInfo(const CarInfo &);




int main()

{



    CarInfo myCar;




    // HARD CODING

    myCar.make = "Porsche";

    myCar.model = "Carrera";

    myCar.engine.displacement = 3.6;

    myCar.engine.horsePower = 380;

    myCar.engine.numberOfCylinders = 6;

    myCar.year = 2015;

    myCar.mpg = 11;







   // list initialization

   //CarInfo myCar = {"Porsche", "Carrera", 2015, 11.5};

   displayCarInfo(myCar);

   return 0;

}




void displayCarInfo(const CarInfo &aCar)

{

    cout << "Make: "  << aCar.make << endl;

    cout << "Model: "  << aCar.model << endl;

    cout << "Year: "  << aCar.year << endl;

    cout << "MPG: "  << aCar.mpg << endl;

    cout << "Displacement: "  << aCar.engine.displacement << endl;

    cout << "Horse Power: "  << aCar.engine.horsePower << endl;

    cout << "NUmber of Cylinders: "  << aCar.engine.numberOfCylinders << endl;




}

