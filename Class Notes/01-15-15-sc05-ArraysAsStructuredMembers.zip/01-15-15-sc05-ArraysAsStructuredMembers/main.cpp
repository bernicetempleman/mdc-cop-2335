#include <iostream>




using namespace std;




const int NUM_QUIZZES = 3;

const int NUM_ASSIGNMENTS = 4;




struct StudentInfo

{

    string name;

    int    id;

    int    quizzes[NUM_QUIZZES];

    int    assignments[NUM_ASSIGNMENTS];

    int    midtermExam;

    int    finalExam;

};




void displayStudent(const StudentInfo &);




int main()

{

    StudentInfo student = {"Dwyane Wade", 1001};




    // populate the quiz scores

    for (int i=0; i<NUM_QUIZZES; i++)

    {

        cout << "Quiz # " << i+1 << " score: ";

        cin >> student.quizzes[i];

    }




    // populate assignment scores

    for (int i=0; i<NUM_ASSIGNMENTS; i++)

    {

        cout << "Assignment # " << i+1 << " score: ";

        cin >> student.assignments[i];

    }




    // hard code MTE, FE

    student.midtermExam = 100;

    student.finalExam = 85;




    displayStudent(student);




    return 0;

}




void displayStudent(const StudentInfo & myStudent)

{

    cout << "Name : " << myStudent.name << endl;

    cout << "ID : " << myStudent.id << endl;




    // display quizzes

    for (int i=0; i<NUM_QUIZZES; i++)

    {

        cout << "Quiz # " << i+1 << " " <<  myStudent.quizzes[i]

             << endl;

    }




    // display assignment

    for (int i=0; i<NUM_ASSIGNMENTS; i++)

    {

        cout << "Assignment # " << i+1 << " " <<   myStudent.assignments[i] << endl;

    }




    cout << "MTE: " << myStudent.midtermExam << endl;

    cout << "Final Exam: " << myStudent.finalExam << endl;

}
