/* Programmer : Bernice Templeman
 * Class      : COP2335
 * Exercise 3 : Hospital Bill
*/

#ifndef HOSPITALBILL_H
#define HOSPITALBILL_H

#include <HospitalCharges.h>

#include <iostream>
#include <string>

using namespace std;

class HospitalBill
{

    private:
        string hospitalName;
        string patientID;
        HospitalCharges hospitalCharges;

    protected:

    public:
      //  HospitalCharges hospitalCharges;

        HospitalBill();

        HospitalBill( string hName, string pid, double pC, double dF, double rC, double xC);

        ~HospitalBill();

        string GethospitalName() { return hospitalName; }

        void SethospitalName(string val) { hospitalName = val; }

        string GetpatientID() { return patientID; }

        void SetpatientID(string val) { patientID = val; }

        HospitalCharges GethospitalCharges() { return hospitalCharges; }

        void SethospitalCharges(HospitalCharges val) { hospitalCharges = val; }

        void print()
        {

            cout << "Hospital Name: " << GethospitalName()<< endl;
            cout << "Patient ID: " << GetpatientID() <<endl;
            hospitalCharges.print();
            /*
            cout << "Hospital Charges:" << endl;
            cout << "   pharmacy: " << hospitalCharges.GetpharmacyCharges() <<endl;
            cout << "   doctor: " << hospitalCharges.GetdoctorFees()<< endl;
            cout << "   room: " << hospitalCharges.GetroomCharges() <<endl;
            cout << "   X-Ray Charges: " << hospitalCharges.GetxRayCharges() <<endl;
            cout << endl <<endl;
            */
        }

};

#endif // HOSPITALBILL_H
