/* Programmer : Bernice Templeman
 * Class      : COP2335
 * Exercise 3 : Hospital Bill
*/

#ifndef PATIENT_H
#define PATIENT_H
#include <string>
#include <Person.h>

class Patient : public Person
{
    private:
        string patientID;
        string dateOfBirth;
        string attendingPhysician;
        string dateAdmittedToHospital;

    protected:

    public:
        Patient();

        Patient( string pid,  string dob, string ap, string dath, string fn, string ln);

        ~Patient();

        string GetpatientID() { return patientID; }

        void SetpatientID(string val) { patientID = val; }

        string GetdateOfBirth() { return dateOfBirth; }

        void SetdateOfBirth(string val) { dateOfBirth = val; }

        string GetattendingPhysician() { return attendingPhysician; }

        void SetattendingPhysician(string val) { attendingPhysician = val; }

        string GetdateAdmittedToHospital() { return dateAdmittedToHospital; }

        void SetdateAdmittedToHospital(string val) { dateAdmittedToHospital = val; }

        void print()
        {
            cout << "Patient: " << GetfirstName()<<" "  << GetlastName()<<endl;
            cout << "Patient ID: "<< GetpatientID() << endl;
            cout << "Date of Birth: "<< GetdateOfBirth()<<endl;
            cout << "Attending Physician: "<< GetattendingPhysician()<<endl;
            cout << "Date Admitted to Hospital: "<< GetdateAdmittedToHospital()<<endl;
            cout << endl <<endl;
        }

};

#endif // PATIENT_H
