/* Programmer : Bernice Templeman
 * Class      : COP2335
 * Exercise 3 : Hospital Bill
*/

#ifndef PERSON_H
#define PERSON_H

#include <iostream>
#include <string>


using namespace std;

class Person
{
    private:
        string firstName;
        string lastName;
    protected:
    public:
        Person();

        Person(string fm, string ln);

        ~Person();

        string GetfirstName() { return firstName; }

        void SetfirstName(string val) { firstName = val; }

        string GetlastName() { return lastName; }

        void SetlastName(string val) { lastName = val; }

        void print() const
        {
            cout << firstName <<" "<<lastName<<endl;
        }


};

#endif // PERSON_H
