/* Programmer : Bernice Templeman
 * Class      : COP2335
 * Exercise 3 : Hospital Bill
*/

#ifndef HOSPITAL_H
#define HOSPITAL_H

#include <iostream>
#include <string>

using namespace std;

class Hospital
{
    private:
        string hospitalName;
        string hospitalURL;
        string hospitalTelephoneNumber;

    protected:

    public:
        Hospital();

        Hospital(string hName, string hURL, string hTN);

        ~Hospital();

        string GetHospitalName() { return hospitalName; }

        void SetHospitalName(string val) { hospitalName = val; }

        string GethospitalURL() { return hospitalURL; }

        void SethospitalURL(string val) { hospitalURL = val; }

        string GethospitalTelephoneNumber() { return hospitalTelephoneNumber; }

        void SethospitalTelephoneNumber(string val) { hospitalTelephoneNumber = val; }

        void print()
        {
            cout << "Hospital: "<< GetHospitalName()<< endl;
            cout << "URL: " << GethospitalURL()<<endl;
            cout << "Telephone: "<< GethospitalTelephoneNumber()<<endl<<endl;
        }
};

#endif // HOSPITAL_H
