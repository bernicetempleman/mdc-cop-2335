/* Programmer : Bernice Templeman
 * Class      : COP2335
 * Exercise 3 : Hospital Bill
*/
#include "HospitalBill.h"
#include <string>

HospitalBill::HospitalBill()
{
    //ctor
}

HospitalBill::HospitalBill( string hName, string pid, double pC, double dF, double rC, double xC)
{
    hospitalName = hName;
    patientID = pid;
    hospitalCharges.set(pC,dF,rC,xC);

}

HospitalBill::~HospitalBill()
{
    cout<< "in HospitalBill destructor"<<endl;
}
