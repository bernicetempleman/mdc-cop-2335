/* Programmer : Bernice Templeman
 * Class      : COP2335
 * Exercise 3 : Hospital Bill
*/

#include "HospitalCharges.h"

HospitalCharges::HospitalCharges()
{
    //ctor
}
HospitalCharges::HospitalCharges(double pharmC, double docF, double roomC, double xC)
{
    pharmacyCharges=pharmC;
    doctorFees= docF;
    roomCharges= roomC;
    xRayCharges= xC;

}
HospitalCharges::~HospitalCharges()
{
    {cout << "In Hospital Charges destructor"<< endl;}
}
