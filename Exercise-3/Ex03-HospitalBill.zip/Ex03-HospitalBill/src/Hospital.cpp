/* Programmer : Bernice Templeman
 * Class      : COP2335
 * Exercise 3 : Hospital Bill
*/

#include "Hospital.h"
#include <string>

using namespace std;



Hospital::Hospital()
{
    //ctor
}

Hospital::Hospital(string hName, string hURL, string hTN)
{
    hospitalName = hName;
    hospitalURL = hURL;
    hospitalTelephoneNumber = hTN;

}

Hospital::~Hospital()
{
    {cout << "In Hospital destructor"<< endl;}
}
