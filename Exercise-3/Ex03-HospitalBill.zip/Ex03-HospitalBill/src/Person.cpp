/* Programmer : Bernice Templeman
 * Class      : COP2335
 * Exercise 3 : Hospital Bill
*/

#include "Person.h"

Person::Person()
{
    //ctor
}

Person::Person(string fn, string ln)
{
    firstName = fn;
    lastName = ln;
}

Person::~Person()
{
    {cout << "In Person destructor"<< endl;}
}
