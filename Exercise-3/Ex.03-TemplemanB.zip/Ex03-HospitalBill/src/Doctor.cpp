/* Programmer : Bernice Templeman
 * Class      : COP2335
 * Exercise 3 : Hospital Bill
*/

#include "Doctor.h"
#include <Person.h>
#include <string>

using namespace std;

Doctor::Doctor()
{
    //ctor
}

Doctor::Doctor(string s, string fn, string ln):
    Person(fn,ln)
{
    Specialty = s;

}

Doctor::~Doctor()
{
    {cout << "In Doctor destructor"<< endl;}
}
