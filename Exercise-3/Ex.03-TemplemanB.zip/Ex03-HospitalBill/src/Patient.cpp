/* Programmer : Bernice Templeman
 * Class      : COP2335
 * Exercise 3 : Hospital Bill
*/

#include "Patient.h"
#include <Person.h>
#include <string>

Patient::Patient()
{
    //ctor
}

Patient::Patient( string pid, string dob, string ap, string dath,  string fn, string ln):
    Person(fn,ln)
{
    patientID = pid;
    dateOfBirth = dob;
    attendingPhysician =  ap;
    dateAdmittedToHospital = dath;
}

Patient::~Patient()
{
    {cout << "In Patient destructor"<< endl;}
}
