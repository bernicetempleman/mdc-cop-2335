/* Programmer : Bernice Templeman
 * Class      : COP2335
 * Exercise 3 : Hospital Bill
*/

#ifndef HOSPITALCHARGES_H
#define HOSPITALCHARGES_H

#include <iostream>
#include <string>

using namespace std;

class HospitalCharges
{
    private:
        double pharmacyCharges;
        double doctorFees;
        double roomCharges;
        double xRayCharges;

    protected:

    public:
        HospitalCharges();

        HospitalCharges(double pharmC, double docF, double roomC, double xC);

        ~HospitalCharges();

        void set(double pharmC, double docF, double roomC, double xC)
        {pharmacyCharges= pharmC; doctorFees = docF; roomCharges=roomC; xRayCharges = xC;}

        double GetpharmacyCharges() { return pharmacyCharges; }

        void SetpharmacyCharges(double val) { pharmacyCharges = val; }

        double GetdoctorFees() { return doctorFees; }

        void SetdoctorFees(double val) { doctorFees = val; }

        double GetroomCharges() { return roomCharges; }

        void SetroomCharges(double val) { roomCharges = val; }

        double GetxRayCharges() { return xRayCharges; }

        void SetxRayCharges(double val) { xRayCharges = val; }

        void print()
        {
            cout << "Hospital Charges:" << endl;
            cout << "   pharmacy: " << GetpharmacyCharges() <<endl;
            cout << "   doctor: " << GetdoctorFees()<< endl;
            cout << "   room: " << GetroomCharges() <<endl;
            cout << "   X-Ray Charges: " << GetxRayCharges() <<endl;
        }
};

#endif // HOSPITALCHARGES_H
