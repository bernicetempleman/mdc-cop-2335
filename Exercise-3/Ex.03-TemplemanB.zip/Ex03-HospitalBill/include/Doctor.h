/* Programmer : Bernice Templeman
 * Class      : COP2335
 * Exercise 3 : Hospital Bill
*/

#ifndef DOCTOR_H
#define DOCTOR_H


#include <Person.h>

#include <iostream>
#include <string>


class Doctor : public Person
{
    private:
        string Specialty;
    protected:
    public:
        Doctor();

        Doctor( string s, string fn, string ln);

        ~Doctor();

        string GetSpecialty() { return Specialty; }

        void SetSpecialty(string val) { Specialty = val; }

        void print()
        {
            cout << "Name: "<< GetfirstName()<<" "<< GetlastName()<<endl;
            cout << "Specialty: " <<Specialty <<endl;
            cout << endl <<endl;
        }



};

#endif // DOCTOR_H
